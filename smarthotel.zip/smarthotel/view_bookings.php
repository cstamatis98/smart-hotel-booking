<?php
include 'db.php';

// Φέρνουμε όλες τις κρατήσεις με πληροφορίες δωματίου
$sql = "SELECT b.id, b.customer_name, b.check_in, b.check_out, r.room_number, r.type, r.price 
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        ORDER BY b.check_in DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8" />
    <title>Προβολή Κρατήσεων</title>
    <style>
        table { border-collapse: collapse; width: 90%; margin: 30px auto; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        h2 { text-align: center; margin-top: 30px; }
        a { text-decoration: none; color: #0066cc; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h2>Όλες οι Κρατήσεις</h2>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Όνομα Πελάτη</th>
            <th>Δωμάτιο</th>
            <th>Τύπος</th>
            <th>Τιμή (€)</th>
            <th>Check-in</th>
            <th>Check-out</th>
            <th>Ενέργειες</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['customer_name']) ?></td>
                    <td><?= htmlspecialchars($row['room_number']) ?></td>
                    <td><?= htmlspecialchars($row['type']) ?></td>
                    <td><?= number_format($row['price'], 2) ?></td>
                    <td><?= htmlspecialchars($row['check_in']) ?></td>
                    <td><?= htmlspecialchars($row['check_out']) ?></td>
                    <td>
                        <a href="edit_booking.php?id=<?= $row['id'] ?>">Επεξεργασία</a> | 
                        <a href="delete_booking.php?id=<?= $row['id'] ?>" onclick="return confirm('Είσαι σίγουρος/η για τη διαγραφή;')">Διαγραφή</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8">Δεν υπάρχουν κρατήσεις.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>



