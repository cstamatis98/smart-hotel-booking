<?php
include 'db.php';

$message = '';
$id = $_GET['id'] ?? null;

if (!$id) {
    die("Μη έγκυρο αίτημα.");
}

// Φόρτωση της κράτησης
$sql = "SELECT * FROM bookings WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$booking = $result->fetch_assoc();

if (!$booking) {
    die("Η κράτηση δεν βρέθηκε.");
}

// Φόρτωση όλων των διαθέσιμων δωματίων (ή όλα τα δωμάτια)
$sql_rooms = "SELECT * FROM rooms";
$result_rooms = $conn->query($sql_rooms);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'] ?? '';
    $room_id = $_POST['room_id'] ?? '';
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';

    if ($customer_name && $room_id && $check_in && $check_out) {
        // Έλεγχος για διαθεσιμότητα (εκτός αυτής της κράτησης)
        $sql_check = "SELECT * FROM bookings WHERE room_id = ? AND id != ? AND 
            ((check_in <= ? AND check_out >= ?) OR (check_in <= ? AND check_out >= ?) OR (check_in >= ? AND check_out <= ?))";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("iissssss", $room_id, $id, $check_in, $check_in, $check_out, $check_out, $check_in, $check_out);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows == 0) {
            // Ενημέρωση κράτησης
            $sql_update = "UPDATE bookings SET customer_name = ?, room_id = ?, check_in = ?, check_out = ? WHERE id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param("sissi", $customer_name, $room_id, $check_in, $check_out, $id);

            if ($stmt_update->execute()) {
                $message = "Η κράτηση ενημερώθηκε με επιτυχία!";
                // Ανανεώνουμε τα δεδομένα μετά την επιτυχή ενημέρωση
                $stmt->execute();
                $result = $stmt->get_result();
                $booking = $result->fetch_assoc();
            } else {
                $message = "Σφάλμα κατά την ενημέρωση της κράτησης.";
            }
        } else {
            $message = "Το δωμάτιο δεν είναι διαθέσιμο για τις επιλεγμένες ημερομηνίες.";
        }
    } else {
        $message = "Παρακαλώ συμπλήρωσε όλα τα πεδία.";
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8" />
    <title>Επεξεργασία Κράτησης</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        form { max-width: 400px; margin: auto; }
        label { display: block; margin-top: 15px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px; width: 100%; background-color: #007bff; color: white; border: none; cursor: pointer; }
        .message { text-align: center; margin: 15px; font-weight: bold; color: green; }
        .error { color: red; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Επεξεργασία Κράτησης</h2>

<?php if ($message): ?>
    <p class="message <?= strpos($message, 'Σφάλμα') !== false || strpos($message, 'δεν είναι διαθέσιμο') !== false ? 'error' : '' ?>">
        <?= htmlspecialchars($message) ?>
    </p>
<?php endif; ?>

<form method="POST" action="">
    <label for="customer_name">Όνομα Πελάτη:</label>
    <input type="text" id="customer_name" name="customer_name" required value="<?= htmlspecialchars($booking['customer_name']) ?>" />

    <label for="room_id">Επιλογή Δωματίου:</label>
    <select id="room_id" name="room_id" required>
        <option value="">-- Επιλέξτε δωμάτιο --</option>
        <?php
        if ($result_rooms->num_rows > 0) {
            while ($row = $result_rooms->fetch_assoc()) {
                $selected = ($row['id'] == $booking['room_id']) ? 'selected' : '';
                echo "<option value='" . $row['id'] . "' $selected>Δωμάτιο " . htmlspecialchars($row['room_number']) . " (" . htmlspecialchars($row['type']) . ") - " . number_format($row['price'], 2) . "€</option>";
            }
        } else {
            echo "<option value=''>Δεν υπάρχουν δωμάτια</option>";
        }
        ?>
    </select>

    <label for="check_in">Ημερομηνία Check-in:</label>
    <input type="date" id="check_in" name="check_in" required value="<?= htmlspecialchars($booking['check_in']) ?>" />

    <label for="check_out">Ημερομηνία Check-out:</label>
    <input type="date" id="check_out" name="check_out" required value="<?= htmlspecialchars($booking['check_out']) ?>" />

    <button type="submit">Ενημέρωση Κράτησης</button>
</form>

<p style="text-align:center; margin-top:20px;">
    <a href="view_bookings.php">Επιστροφή στις Κρατήσεις</a>
</p>

</body>
</html>
