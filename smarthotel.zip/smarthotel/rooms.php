<?php
include 'db.php';

// Ερώτημα για να φέρουμε όλα τα δωμάτια
$sql = "SELECT * FROM rooms";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8" />
    <title>Διαθεσιμότητα Δωματίων</title>
    <style>
        table {
            border-collapse: collapse;
            width: 70%;
            margin: 20px auto;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        .available {
            background-color: #d4edda;
            color: #155724;
            font-weight: bold;
        }
        .booked {
            background-color: #f8d7da;
            color: #721c24;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">Διαθεσιμότητα Δωματίων Ξενοδοχείου</h2>

<table>
    <tr>
        <th>Αριθμός Δωματίου</th>
        <th>Τύπος</th>
        <th>Τιμή (€)</th>
        <th>Κατάσταση</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $statusClass = ($row['status'] == 'available') ? 'available' : 'booked';
            echo "<tr>
                    <td>" . htmlspecialchars($row['room_number']) . "</td>
                    <td>" . htmlspecialchars($row['type']) . "</td>
                    <td>" . number_format($row['price'], 2) . "</td>
                    <td class='$statusClass'>" . ucfirst($row['status']) . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='4'>Δεν βρέθηκαν δωμάτια.</td></tr>";
    }
    ?>
</table>

</body>
</html>



