<?php
include 'db.php';

$message = '';

// Όταν υποβληθεί η φόρμα
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'] ?? '';
    $room_id = $_POST['room_id'] ?? '';
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';

    // Απλή επαλήθευση
    if ($customer_name && $room_id && $check_in && $check_out) {
        // Έλεγχος αν το δωμάτιο είναι διαθέσιμο στην περίοδο αυτή
        $sql_check = "SELECT * FROM bookings WHERE room_id = ? AND 
            ( (check_in <= ? AND check_out >= ?) OR (check_in <= ? AND check_out >= ?) OR (check_in >= ? AND check_out <= ?) )";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("issssss", $room_id, $check_in, $check_in, $check_out, $check_out, $check_in, $check_out);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows == 0) {
            // Εισαγωγή κράτησης
            $sql_insert = "INSERT INTO bookings (customer_name, room_id, check_in, check_out) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("siss", $customer_name, $room_id, $check_in, $check_out);
            if ($stmt_insert->execute()) {
                $message = "Η κράτηση πραγματοποιήθηκε με επιτυχία!";
            } else {
                $message = "Σφάλμα κατά την αποθήκευση της κράτησης.";
            }
        } else {
            $message = "Το δωμάτιο δεν είναι διαθέσιμο για τις ημερομηνίες που επέλεξες.";
        }
    } else {
        $message = "Παρακαλώ συμπλήρωσε όλα τα πεδία.";
    }
}

// Φέρνουμε τα διαθέσιμα δωμάτια για την επιλογή
$sql_rooms = "SELECT * FROM rooms WHERE status = 'available'";
$result_rooms = $conn->query($sql_rooms);
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8" />
    <title>Κράτηση Δωματίου</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        form { max-width: 400px; margin: auto; }
        label { display: block; margin-top: 15px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px; width: 100%; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        .message { text-align: center; margin: 15px; font-weight: bold; color: green; }
        .error { color: red; }
    </style>
</head>
<body>

<h2 style="text-align:center;">Κράτηση Δωματίου</h2>

<?php if ($message): ?>
    <p class="message <?= strpos($message, 'Σφάλμα') !== false || strpos($message, 'δεν είναι διαθέσιμο') !== false ? 'error' : '' ?>">
        <?= htmlspecialchars($message) ?>
    </p>
<?php endif; ?>

<form method="POST" action="booking.php">
    <label for="customer_name">Όνομα Πελάτη:</label>
    <input type="text" id="customer_name" name="customer_name" required />

    <label for="room_id">Επιλογή Δωματίου:</label>
    <select id="room_id" name="room_id" required>
        <option value="">-- Επιλέξτε δωμάτιο --</option>
        <?php
        if ($result_rooms->num_rows > 0) {
            while ($row = $result_rooms->fetch_assoc()) {
                echo "<option value='" . $row['id'] . "'>Δωμάτιο " . htmlspecialchars($row['room_number']) . " (" . htmlspecialchars($row['type']) . ") - " . number_format($row['price'], 2) . "€</option>";
            }
        } else {
            echo "<option value=''>Δεν υπάρχουν διαθέσιμα δωμάτια</option>";
        }
        ?>
    </select>

    <label for="check_in">Ημερομηνία Check-in:</label>
    <input type="date" id="check_in" name="check_in" required />

    <label for="check_out">Ημερομηνία Check-out:</label>
    <input type="date" id="check_out" name="check_out" required />

    <button type="submit">Κράτηση</button>
</form>

</body>
</html>


