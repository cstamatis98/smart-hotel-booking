<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM bookings WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: view_bookings.php?msg=deleted");
        exit;
    } else {
        echo "Σφάλμα κατά τη διαγραφή.";
    }
} else {
    echo "Μη έγκυρο αίτημα.";
}
?>
