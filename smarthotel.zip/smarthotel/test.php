<?php
include 'db.php';
echo "Η σύνδεση με τη βάση ήταν επιτυχής!";
?>



