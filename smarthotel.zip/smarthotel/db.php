<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'smarthotel';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Σφάλμα σύνδεσης: " . $conn->connect_error);
}
?>



